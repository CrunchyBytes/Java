/* ID: 160046
 * Name: Alexander Díaz Ruiz
 * Date: 
 */
package interfaz;

import java.awt.HeadlessException;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexander
 */
public class Array 
{
    //        
        int size, count, array [];
        
    /*Constructor 
        * Didn't bother adding the size 
        */
        public Array(/*int s*/)
        {
            //size/* = s*/;
            count = 0;
            //array = new int[size];
            
            boolean pass = false;
            do
            {
                try
                {
                    size = Integer.parseInt(JOptionPane.showInputDialog(null, "Por favor ingrese el número de enteros a guardar: ", "Creación de Arreglo", JOptionPane.INFORMATION_MESSAGE));

                    if (size>0)
                    
                        pass = true;
                    
                    else
                    
                        JOptionPane.showMessageDialog(null, "No es posible almacenar información en un arreglo de tamaño nulo o negativo.\nPor favor ingrese un tamaño válido.", "Tamaño de Arreglo inválido", JOptionPane.WARNING_MESSAGE);                
                    
                  // The IDE itself suggested to replace regular ordinary <Exception e> to the following, more specific exceptions. 
                } catch (HeadlessException | NumberFormatException e)
                {
                    if (e.getMessage().equals("null"))
                        System.exit(0);
                    else
                    {
                        JOptionPane.showMessageDialog(null, "Lo sentimos, el dato que usted ha ingresado no es de tipo entero.\nFavor de intentarlo nuevamente.", "Tipo de Dato erróneo", JOptionPane.ERROR_MESSAGE);
                        System.out.println("Error de tipo: " + e.getMessage());
                    }        
                }
            } while (pass==false);
            
            array = new int[size];
            
            System.out.println("New size: " + size + "\nArray Dimension: " + array.length + "\nCount: " + count);
            //pass = false;     Decided to not include it in the constructor, as it's not a variable to be present within each instance
        }
     
        
    // Methods   
        /* I figured it wouldn't be important to include an argument, given that the User doesn't interact with the Source Code in
           in any way as to provide a parameter in the first place.
         */
        public void insertOneElement(/*int i*/)
        {
            boolean pass = false;
            /* Como el valor de <num> se le asigna dentro de un try-catch, pero se emplea fuera de él, el IDE pide inicializarlo con
               anticipación
             */
            int num = -999999;
            
            /*try
            {
                if (count < size)
                {
                    */do
                    {
                        try
                        {
                            num = Integer.parseInt(JOptionPane.showInputDialog(null, "Inserte por favor el número entero a guardar en el arreglo: ", "Implementación de un elemento", JOptionPane.INFORMATION_MESSAGE));
                            
                            if (count<array.length)
                            {
                                array[count] = num;
                                count++;
                                
                                JOptionPane.showMessageDialog(null, "Número añadido exitosamente al arreglo.\nFavor de seleccionar la opción 'Show Contents' del menú con tal de ver reflejada la acción.", "Operación Exitosa", JOptionPane.INFORMATION_MESSAGE);

                                pass = true;
                                System.out.println("Array length: " + array.length);
                            }
                            else
                            {
                                JOptionPane.showMessageDialog(null, "No hay memoria suficiente para añadir más datos.\nFavor de eliminar elementos del arreglo para liberar espacio.", "Tipo de Dato erróneo", JOptionPane.WARNING_MESSAGE);
                                pass = true;
                            }                                

                        } catch (HeadlessException | NumberFormatException | ArrayIndexOutOfBoundsException e)
                        {
                            
                            /*else*/ if (e.getMessage().equals("null"))
                            {
                                System.out.println("Ha decidido no insertar.");
                                pass = true;
                            }
                                //System.exit(0);
                            
                            else
                            {
                                JOptionPane.showMessageDialog(null, "El dato que ha solicitado ingresar no es de tipo entero.\nLe pedimos de favor ingresar un dato aceptable.", "Tipo de Dato erróneo", JOptionPane.ERROR_MESSAGE);
                                System.out.println("Error de tipo:" + e);
                            }   
                        }
                    } while (pass==false);
            
            System.out.println("\nNúmero ingresado: " + num + "\nCount: " + count);
        }
        
        public void insertAllFromFile()
        {
            File file = new File ("Sample Data.txt");
            try
            {
                Scanner scan = new Scanner(file);
              
                do
                {              
                    array[count] = Integer.parseInt(scan.nextLine());
                    count++;

                } while (scan.hasNextLine()!=false);
                
                JOptionPane.showMessageDialog(null, "Todos los números del archivo han sido agregados exitosamente al arreglo.\nFavor de seleccionar la opción 'Show Contents' del menú con tal de ver reflejada la acción.", "Importe Exitoso", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Count: " + count);
                
            } catch(IOException | NumberFormatException | ArrayIndexOutOfBoundsException e)
            {
                if (count == array.length)
                {
                    JOptionPane.showMessageDialog(null, "Lo sentimos, el arreglo no pudo almacenar todos los datos del archivo.\nSólo se guardaron los primeros que encontraron lugar.", "Exceso de datos en archivo", JOptionPane.WARNING_MESSAGE);
                    System.out.println("Error: " + e);
                } 

                else
                {
                    JOptionPane.showMessageDialog(null, "No ha sido posible añadir datos del archivo.", "Error al leer el archivo.", JOptionPane.ERROR_MESSAGE);
                    System.out.println("Error: " + e);
                }     
            }
            
        }
        
        /* Works like a charm
         * I was afraid that <str> and <i> would return to their default, initialized values if the Method was summoned more than once
           Thankfully, they don't.
         * Oh wait. Of course they wouldn't.
         */
        public void deleteOne()
        {
            int num, pos;
            boolean found = false;
            
            try
            {
                num = Integer.parseInt(JOptionPane.showInputDialog(null, "Favor de ingresar el número entero a eliminar del arreglo: ", "Borrar elemnto", JOptionPane.INFORMATION_MESSAGE));
                
                for (int i=0; i<count; i++)
                {
                    if (array[i]==num)
                    {
                        found = true;
                        pos = i;
                        
                        for (int j=pos; j<count; j++)    
                            array[j] = array[j+1];
                        
                        count--;
                    }
                }
                
                if (found==true)
                    JOptionPane.showMessageDialog(null, "Número(s) eliminado exitosamente del arreglo.\nFavor de seleccionar la opción 'Show Contents' del menú con tal de ver reflejada la acción.", "Operación Exitosa", JOptionPane.INFORMATION_MESSAGE);
                else
                    JOptionPane.showMessageDialog(null, "Element not found.", "Búsqueda fallida", JOptionPane.WARNING_MESSAGE);

            } catch (Exception e)
            {
                if (e.getMessage().equals("null"))
                    System.out.println("Ha decidido no eliminar.");

                else
                {
                    JOptionPane.showMessageDialog(null, "El dato que ha solicitado ingresar no es de tipo entero.\nLe pedimos de favor ingresar un dato aceptable.", "Tipo de Dato erróneo", JOptionPane.ERROR_MESSAGE);
                    System.out.println("Error de tipo:" + e);
                }
            }
        }
        
        public String showContents()
        {
            String str = "";
            
            for (int i=0; i<count; i++)
            {
                str = str + (i+1) + ". " + array[i] + "\n";
            }
            
            System.out.println("Count: " + count);
            
           return str;
        }
        
        /* Receives 3 existing arrays: the "original" ('a'), per se, and another two whith each containing half of 
           the elements as 'a'. 'L' containing the left half, 'r' containing the right.
        
        
         * I USED AN EXTERNAL SOURCE AS A REFERENCE TO DEVELOP THE mergesort() AND merge() METHODS.
           ITS APA REFERENCE IS AS FOLLOWS:
           mycodeschool. (2013, July 2). Merge sort algorithm [Video file]. Retrieved from https://www.youtube.com/watch?v=TzeBrDU-JaY
        
        
         * To not confuse the letter 'l' with the number "1", I decided instead to use its uppercase variant.
         * It's also worth noting that it returns an integer: moveCounter, which keeps track of the number of
           swaps required to sort a's data properly.
         */
        public int merge(int[] a, int[] L, int[] r)
        {
            int moveCounter = 0;
            // Indexes for the array arguments 'a', 'L', and 'r' correspondingly.
            int i=0, j=0, k=0;
            
            /* Whilst either of the sub-array indexes hasn't traversed the entirety of their own sub-array, keep on 
               comparing each element of said sub-array to each element of the other in order to see which is the smallest.
             * Winner gets to be inserted into 'a': the definite array.
             * At the end of either assignment, moveCounter incrases by 1.
             */
            while(j<L.length && k<r.length)
            {
                if (L[j] <= r[k])
                {
                    a[i] = L[j];
                    j++;
                }
                else
                {
                    a[i] = r[k];
                    k++;
                }                
                i++;
                moveCounter++;
            }
            
            /* Given that either 'L' or 'r' will undoubtedly finish one before the other, the past while-loop
               will prove to be unable to merge/sort the remaining elements of the unfinished array.
             * That is why the two following while-loops exist: to finish the merging from 'L' and 'r' to the
               main one--whichever sub-array it might be.
             */
            while (j<L.length)
            {
                a[i] = L[j];                
                i++;
                j++;
                moveCounter++;
            }
            
            while (k<r.length)
            {
                a[i] = r[k];                
                i++;
                k++;
                moveCounter++;
            }
            /* I originally tried to do a for-cycle within an if-condtion, so as to step away from the tuto-
               rial and actually do something I had thought for myself; but for some reason, it turned out to 
               be less efficient.
             * Not only in terms of time/memory/lines of code, but the copied data would often skip a number
               presented in the array, and instead replace it with another.
             * In some occassions, it would simply stop sorting as usual and rearrange the array with no visi-
               ble order.
            
            if (j<L.length)
            {
                for (int h=j; h<L.length; h++)
                {
                    a[i] = L[h];
                    i++;
                }
            }
            else if (k<r.length)
            {
                for (int h=k; h<L.length; h++)
                {
                    a[i] = r[h];
                    i++;
                }
            }*/
            return moveCounter;
        }
        
        /* Used a different variant than what was seen in class. Said variant relies on two methods: one which 
           recursively splits the array in two (mergesort()), whilst the other is in charge of merging said 
           splits while it sorts its contents (merge()) all the way back to the original array's size.     
         * Depends on a variable that calculates the center of the array, 'middle', in order to split it a-
           ccordingly in halves.

        
         * I USED AN EXTERNAL SOURCE AS A REFERENCE TO DEVELOP THE mergesort() AND merge() METHODS.
           ITS APA REFERENCE IS AS FOLLOWS:
           mycodeschool. (2013, July 2). Merge sort algorithm [Video file]. Retrieved from https://www.youtube.com/watch?v=TzeBrDU-JaY
        
        
         * Returns the number of movements required to arrange the desired array, movementNumber, to the inter-
           face class: Frm_GUI.
         */
        public int mergesort(int a[])
        {
            int movementNumber = 0, middle, n = a.length;
                       
            /* To break the recursive nature of this method, a condition must be met.
               That is why it will only continue to execute as long as the length of the array received as an
               argument is greater than 1--because one cannot split an array any further than a single cell.
             * Tried a do-while condition but it just wouldn't work.
               Came back to an if-condition instead.
             */
            if (n>1)
            {
                // For development purposes. Keeps track of the length of each sub-array iteration.
                System.out.println("N: " + n);
                
            /*do
            {
                if (n<2)
                {
                    keepOn=false;
                }
                else
                {*/                                               
                middle = n/2;

                /* I orginally had both arrays have their size set to "middle"; however, I soon realized that
                   the pseudocode had purposely implemented "n-middle", as in cases where a's length is an odd
                   number, having both arrays set to a length equal to 'middle' would mean that one element
                   from 'a'--the last one--wouldn't be considered when transferring content to the sub-arrays.                
                 */
                int left[] = new int[middle];
                int right[] = new int[n-middle];

                /* Intialization of sub arrays. Takes content of each half.
                 * I originally intended to simplify the process of assignation into one for-loop instaed of
                   the two proposed by the source, but for some reason, it simply won't work as well.
                   I even did the math step-by-step and it's supposed to be the same. 
                 * I have no clue as to why my algorithm isn't as efficient or works as properly as the 
                   source's pseudocode, so I used the latter to at least ensure that the program runs
                   smooth and adequately.                .
                 */
                for (int i=0; i<middle; i++)
                {
                    left[i] = a[i];
                    //right[i] = a[i+middle];
                }
                
                for (int i=middle; i<n; i++)
                {
                    right[i-middle] = a[i];
                }

                mergesort(left);
                mergesort(right);

                movementNumber = merge(a, left, right);   
            }
            
            return movementNumber;     
        }           
}