/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file.chooser;

import java.io.File;
import java.io.IOException;
import javax.swing.JFileChooser;

/**
 *
 * @author Alexander
 */
public class FileChooser {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        File file = new File("Prueba.txt");
                
        /* Incluso si se declaró el archivo, no se considera "creado" hasta que se ejecuta el método
           'createNewFile()'.
         * Sin embargo, ese método nada más regresa true si el archivo no existía con anterioridad; si 
           se quiere comprobar que un archivo previamente creado siga existiendo, se ocupa el método 
           exist().
         */
        if (file.createNewFile())
            System.out.println("Archivo creado exitosamente.");
        else
            System.out.println("El archivo ya se encontraba creado.");
        
        /* JFileChooser es esa herramienta que abre una ventana con tal de seleccionar un archivo o progra-
           ma en específico.
         * Así como cuando quieres abrir algo/guardar algo en un directorio particular.
         */
        JFileChooser chooser = new JFileChooser("Prueba.txt");
        
        int status = chooser.showOpenDialog(null);
        
        /* Dependiendo de lo que hagas, ya sea escoger un archivo o cerrar la ventana, se devuelve un en-
           tero.
         * Entre las 3 opciones posibles se encuentran:
           APPROVE_OPTION: Lo cual quiere decir que escogiste algo.
           CANCEL_OPTION: Se explica por sí solo.
         */
        /* Si el usuario escogió un archivo a abrir, se crea una variable 'selectedFile' de tipo File, la
           cual es el archivo seleccionado desde el JFileChooser.
         * Una vez que se haya guardado el archivo seleccionado, se imprime su nombre y su directorio.
         */
        if (status == JFileChooser.APPROVE_OPTION)
        {
            File selectedFile = chooser.getSelectedFile();
            System.out.println("APROBADO: " + selectedFile.getName() + ", localizado en: " + selectedFile.getPath());
        }
        // Si no se escogió ningún archivo, entonces nada más se menciona que se canceló la operación.
        else if (status == JFileChooser.CANCEL_OPTION)
        {
            System.out.println("CANCELADO");
        }

    }
    
    
}
