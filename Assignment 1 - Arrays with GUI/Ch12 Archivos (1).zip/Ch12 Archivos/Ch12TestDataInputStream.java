/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: Illustrate the use of DataOutputStream

    File: Ch12TestDataInputStream.java
*/

import java.io.*;

/**
 *  A test program to read data to a file using DataInputStream for
 *   high level i/o.
 *
 * @author Dr Caffeine
 */
class Ch12TestDataInputStream {
   public static void main (String[] args) throws IOException {

      //setup file and stream
      File            inFile       = new File("sample2.data");
      FileInputStream inFileStream = new FileInputStream(inFile);
      DataInputStream inDataStream = new DataInputStream(inFileStream);

      //read values back from the stream and display them
      System.out.println(inDataStream.readInt());
      System.out.println(inDataStream.readLong());
      System.out.println(inDataStream.readFloat());
      System.out.println(inDataStream.readDouble());
      System.out.println(inDataStream.readChar());
      System.out.println(inDataStream.readBoolean());

      //input done, so close the stream
      inDataStream.close();
   }
}
