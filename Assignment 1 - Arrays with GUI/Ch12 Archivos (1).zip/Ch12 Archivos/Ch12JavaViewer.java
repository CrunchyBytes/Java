/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: Display a Java source file.

    File: Ch12JavaViewer.java

*/

import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;


class Ch12JavaViewer extends JFrame implements ActionListener {

//----------------------------------
//    Data Members
//----------------------------------

    /**
     * Default frame width
     */
    private static final int FRAME_WIDTH    = 450;

    /**
     * Default frame height
     */
    private static final int FRAME_HEIGHT   = 600;

    /**
     * X coordinate of the frame default origin point
     */
    private static final int FRAME_X_ORIGIN = 150;

    /**
     * Y coordinate of the frame default origin point
     */
    private static final int FRAME_Y_ORIGIN = 250;

    /**
     * JTextArea for displaying the source file
     */
    private JTextArea textArea;


//----------------------------------
//      Main method
//----------------------------------
    public static void main(String[] args) {
        Ch12JavaViewer frame = new Ch12JavaViewer();
        frame.setVisible(true);
    }

//----------------------------------
//    Constructors
//----------------------------------

    /**
     * Default constructor
     */
    public Ch12JavaViewer()
    {
        Container contentPane;

        //set the frame properties
        setTitle     ("Ch12JavaViewer: Displaying Java Source File");
        setSize      (FRAME_WIDTH, FRAME_HEIGHT);
        setLocation  (FRAME_X_ORIGIN, FRAME_Y_ORIGIN);


        contentPane = getContentPane( );
        contentPane.setBackground( Color.white );

        textArea = new JTextArea();
        textArea.setEditable(false);
        contentPane.add(new JScrollPane(textArea));
        createMenu();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }


//-------------------------------------------------
//      Public Methods:
//
//          void    actionPerformed   (   ActionEvent        )
//
//------------------------------------------------

    /**
     * Standard method to respond the action event.
     *
     * @param event the ActionEvent object
     *
     */
    public void actionPerformed(ActionEvent event) {
        String  menuName;

        menuName = event.getActionCommand();

        if (menuName.equals("Quit")) {
           System.exit(0);

        } else {
       //    assert menuName.equals("Open");
           openFile( );
        }
    }


//-------------------------------------------------
//      Private Methods:
//
//          void   createFileMenu   (           )
//          void   createEditMenu   (           )
//
//------------------------------------------------

    /**
     * Create File menu and its menu items
     *
     */
    private void createMenu( ) {
        JMenuItem   item;
        JMenuBar    menuBar  = new JMenuBar();
        JMenu       fileMenu = new JMenu("File");

        item = new JMenuItem("Open...");    //Open...
        item.addActionListener( this );
        fileMenu.add( item );

        fileMenu.addSeparator();           //add a horizontal separator line

        item = new JMenuItem("Quit");       //Quit
        item.addActionListener( this );
        fileMenu.add( item );

        setJMenuBar(menuBar);
        menuBar.add(fileMenu);
    }

    /**
     * Let the end user select the Java source file
     * to open.
     */
    private void openFile( ) {

        JFileChooser chooser;
        int          status;

        chooser = new JFileChooser( );

        chooser.setFileFilter(new JavaFilter());

        //Modify the sample path "N:/Programs" to fit your environment
      //  chooser.setCurrentDirectory(new File("N:/Programs"));

        status = chooser.showOpenDialog(null);

        if (status == JFileChooser.APPROVE_OPTION) {
            readSource(chooser.getSelectedFile());

        } else {
            JOptionPane.showMessageDialog(null, "Open File dialog canceled");
        }
    }

    /**
     * Opens the selected file and displays the file content
     *
     * @param file the file to open
     *
     * @exception IOException
     */
    private void readSource(File file) {

        try {
            FileManager fm = new FileManager();
            textArea.setText(fm.openFile(file.getAbsolutePath()));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error in opening a file: \n"
                                            + e.getMessage());
        }

        //The following code shows how to input the content of a text file
        //without using the FileManager class. If we read the
        //body of FileManger's openFile method,we will find something
        //very similar to the following code
/*
        String lineSeparator = System.getProperty("line.separator");

        try {

            FileReader     fileReader = new FileReader(file);
            BufferedReader bufReader  = new BufferedReader(fileReader);
            String         line;

            while (true) {
                line = bufReader.readLine();

                if (line == null) {
                    return;
                }

                textArea.append(line + lineSeparator);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error in opening a file: \n"
                                            + e.getMessage());
      }
*/
    }
}
