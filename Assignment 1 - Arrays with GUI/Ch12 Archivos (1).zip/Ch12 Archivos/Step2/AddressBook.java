/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: The AddressBook class

    File: AddressBook.java
*/

/**
 *   The same AddressBook class from Chapter 11
 *
 * @author Dr Caffeine
 */

interface AddressBook {

//-------------------------------------------------
//      Public Methods:
//
//          void      add       (   Person     )
//          void      delete    (   String     )
//          Person    search    (   String     )
//          Person[ ] sort      (   int        )
//
//------------------------------------------------

    /**
     * Adds a new Person to this address book.
     * If the overflow occurs, the array size
     * is increased by 50 percent.
     *
     * @param newPerson a new Person object to add
     */
    public void add( Person newPerson );


    /**
     * Deletes the Person whose name is 'searchName'.
     *
     * @param searchName the name of a Person to delete
     *
     * @return true if removed successfully; false otherwise
     */
    public boolean delete( String searchName );


    /**
     * Searches this address book for a Person
     * whose name is <code>searchName</code>.
     *
     * @param searchName the name to search
     *
     * @return a Person object if found; otherwise null
     */
    public Person search( String searchName );


    /**
     * Sorts the address book using 'attribute'
     * as the criteria for sorting.
     *
     * @param attribute the attribute of Person used for sorting
     *
     * @return a sorted list of Person
     */
    public Person[ ] sort ( int attribute );

}