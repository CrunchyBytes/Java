/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: Driver class to test
                               the skeleton AddressBookStorage

    File: TestAddressBookStorage.java (Step 1)
*/

/**
 * A test program to verify the setFile method of
 * the AddressBookStorage class.
 *
 * @author Dr Caffeine
 */
class TestAddressBookStorage {

   public static void main (String[] args) {

      AddressBookStorage fileManager;

      fileManager = new AddressBookStorage("one.data");
      fileManager.setFile("two.data");
      fileManager.setFile("three.data");
   }
}