/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: The class that provides the
                                file I/O for AddressBook

    File: AddressBookStorage.java (Step 1)
*/

/**
 * This class provides a file i/o capability to save
 * and load the AddressBook object.
 *
 * @author Dr. Caffeine
 */
class AddressBookStorage {

//--------------------------------
//    Data Members
//--------------------------------

    /**
     * The name of the file where an AddressBook is stored
     */
   private String filename;

//--------------------------------
//    Constructors
//--------------------------------

    /**
     * Default constructor.
     */
   public AddressBookStorage ( String filename ) {
      setFile(filename);
   }

//-------------------------------------------------
//      Public Methods:
//
//          void    setFile       (   String     )
//
//------------------------------------------------

    /**
     *
     *
     * @param filename the name of the file to store
     *        an AddressBook object
     */
   public void setFile(String filename) {
      this.filename = filename;
      System.out.println("Inside setFile. Filename is " + filename); //TEMP
   }

}