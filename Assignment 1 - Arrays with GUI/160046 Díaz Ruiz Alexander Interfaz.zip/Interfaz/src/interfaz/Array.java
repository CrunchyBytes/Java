/* ID: 160046
 * Name: Alexander Díaz Ruiz
 * Date: 
 */
package interfaz;

import java.awt.HeadlessException;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexander
 */
public class Array 
{
    /* Datos Miembro
     * It is necessary that both 'size' and 'count' be a static variabe, as
       their stored values will be both recovered and altered according to each
       Menu Item.
     */
        //Frm_GUI thing = new Frm_GUI();
        
        int size, count, array [];
        
        //boolean pass = false;
        
    /*Constructor 
        * Didn't bother adding the size 
        */
        public Array(/*int s*/)
        {
            //size/* = s*/;
            count = 0;
            //array = new int[size];
            
            boolean pass = false;
            do
            {
                try
                {
                    /*newArray.this.*/size/*size*/ = Integer.parseInt(JOptionPane.showInputDialog(null, "Por favor ingrese el número de enteros a guardar: ", "Creación de Arreglo", JOptionPane.INFORMATION_MESSAGE));

                    if (/*newArray.this.*/size>0)
                    
                        pass = true;
                        //test.array[0] = 6;
                    
                    else
                    
                        JOptionPane.showMessageDialog(null, "No es posible almacenar información en un arreglo de tamaño nulo o negativo.\nPor favor ingrese un tamaño válido.", "Tamaño de Arreglo inválido", JOptionPane.WARNING_MESSAGE);                
                    
                  // The IDE itself suggested to replace regular ordinary <Exception e> to the following, more specific exceptions. 
                } catch (HeadlessException | NumberFormatException e)
                {
                    if (e.getMessage().equals("null"))
                        System.exit(0);
                    else
                    {
                        JOptionPane.showMessageDialog(null, "Lo sentimos, el dato que usted ha ingresado no es de tipo entero.\nFavor de intentarlo nuevamente.", "Tipo de Dato erróneo", JOptionPane.ERROR_MESSAGE);
                        System.out.println("Error de tipo: " + e.getMessage());
                    }        
                }
            } while (pass==false);
            
            //test = new Array(this.size
            //return size;
            //test.size = this.size;
            // size;
            array = new int[size];
            
            System.out.println("New size: " + size + "\nArray Dimension: " + array.length + "\nCount: " + count);
            //pass = false;     Decided to not include it in the constructor, as it's not a variable to be present within each instance
        }
     
        //Array test;
        
    // Methods
        /*public void setSize()
        {
            boolean pass = false;
            do
            {
                try
                {
                    /*newArray.this.*///size/*size*/ = Integer.parseInt(JOptionPane.showInputDialog(null, "Por favor ingrese el número de enteros a guardar: ", "Creación de Arreglo", JOptionPane.INFORMATION_MESSAGE));

                    //if (/*newArray.this.*/size>0)
                    /*{
                        pass = true;
                        //test.array[0] = 6;
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "No es posible almacenar información en un arreglo de tamaño nulo o negativo.\nPor favor ingrese un tamaño válido.", "Tamaño de Arreglo inválido", JOptionPane.WARNING_MESSAGE);                
                    }
                  // The IDE itself suggested to replace regular ordinary <Exception e> to the following, more specific exceptions. 
                } catch (HeadlessException | NumberFormatException e)
                {
                    JOptionPane.showMessageDialog(null, "Lo sentimos, el dato que usted ha ingresado no es de tipo entero.\nFavor de intentarlo nuevamente.", "Tipo de Dato erróneo", JOptionPane.WARNING_MESSAGE);
                    System.out.println("Error de tipo:" + e);
                }
            } while (pass==false);
            
            //test = new Array(this.size
            //return size;
            //test.size = this.size;
            // size;
            System.out.println("New size: " + size + "\nArray Dimension: " + array.length);
        }*/
        
        /* I figured it wouldn't be important to include an argument, given that the User doesn't interact with the Source Code in
           in any way as to provide a parameter in the first place.
         */
        public void insertOneElement(/*int i*/)
        {
            boolean pass = false;
            /* Como el valor de <num> se le asigna dentro de un try-catch, pero se emplea fuera de él, el IDE pide inicializarlo con
               anticipación
             */
            int num = -999999;
            
            /*try
            {
                if (count < size)
                {
                    */do
                    {
                        try
                        {
                            num = Integer.parseInt(JOptionPane.showInputDialog(null, "Inserte por favor el número entero a guardar en el arreglo: ", "Implementación de un elemnto", JOptionPane.INFORMATION_MESSAGE));
                            
                            if (count<array.length)
                            {
                                array[count] = num;
                                count++;
                                
                                JOptionPane.showMessageDialog(null, "Número añadido exitosamente al arreglo.\nFavor de seleccionar la opción 'Show Contents' del menú con tal de ver reflejada la acción.", "Operación Exitosa", JOptionPane.INFORMATION_MESSAGE);

                                pass = true;
                                System.out.println("Array length: " + array.length);
                            }
                            else
                            {
                                JOptionPane.showMessageDialog(null, "No hay memoria suficiente para añadir más datos.\nFavor de eliminar elementos del arreglo para liberar espacio.", "Tipo de Dato erróneo", JOptionPane.WARNING_MESSAGE);
                                pass = true;
                            }
                                

                                

                            /* 
                             * 
                            if (num - Integer.parseInt(Integer.toString(num)) == 0)
                            {  JOptionPane.showMessageDialog(null, "Número añadido exitosamente al arreglo.\nFavor de seleccionar la opción 'Show Contents' del menú con tal de ver reflejada la acción.", "Operación Exitosa", JOptionPane.INFORMATION_MESSAGE);

                                pass = true;
                                System.out.println(array.length);/*
                            /*} else
                            {*/
                                /* 


                                JOptionPane.showMessageDialog(null, "El número que ha solicitado ingresar no es de tipo entero.\nLe pedimos de favor ingresar un dato.", "Tipo de Dato erróneo", JOptionPane.WARNING_MESSAGE);
                            }*/

                        } catch (HeadlessException | NumberFormatException | ArrayIndexOutOfBoundsException e)
                        {
                            
                            /*else*/ if (e.getMessage().equals("null"))
                            {
                                System.out.println("Ha decidido no insertar.");
                                pass = true;
                            }
                                //System.exit(0);
                            
                            else
                            {
                                JOptionPane.showMessageDialog(null, "El dato que ha solicitado ingresar no es de tipo entero.\nLe pedimos de favor ingresar un dato aceptable.", "Tipo de Dato erróneo", JOptionPane.ERROR_MESSAGE);
                                System.out.println("Error de tipo:" + e);
                            }
                                
                                
                            
                        }
                    } while (pass==false);

                    /*} while (pass==false);
                } else
                {
                    JOptionPane.showMessageDialog(null, "No hay memoria suficiente para añadir más datos.\nFavor de eliminar elementos del arreglo para liberar espacio.", "Tipo de Dato erróneo", JOptionPane.WARNING_MESSAGE);
                } 
            } catch (java.lang.ArrayIndexOutOfBoundsException e)
                {
                    JOptionPane.showMessageDialog(null, "No hay memoria suficiente para añadir más datos.\nFavor de eliminar elementos del arreglo para liberar espacio.", "Tipo de Dato erróneo", JOptionPane.WARNING_MESSAGE);
                    System.out.println("Error de tipo:" + e);
                }*/
            
            
                
            /*array[count] = num;
            count++;*/
            
            /*if (count >= array.length)
                            {
                                JOptionPane.showMessageDialog(null, "No hay memoria suficiente para añadir más datos.\nFavor de eliminar elementos del arreglo para liberar espacio.", "Tipo de Dato erróneo", JOptionPane.WARNING_MESSAGE);
                                //System.out.println("Error de tipo:" + e);
                            }*/
            
            System.out.println("\nNúmero ingresado: " + num + "\nCount: " + count);
        }
        
        public void insertAllFromFile()
        {
            File file = new File ("C:\\Users\\Alexander\\Desktop\\WHARRGARBL\\UDLAP\\Quinto Semestre\\Estructuras de Datos\\Assignment 1 - Arrays with GUI\\Sample Data.txt");
            //File file = new File (System.getProperty("user.dir"));
            try
            {
                Scanner scan = new Scanner(file);

                /*String ret="";
                int retCount=0, num;*/
                //int num;
                //int recoveredInt;
                //FileReader fw = new FileReader(file);
                /*BufferedReader bw = new BufferedReader(fw);
                BufferedReader bw2 = new BufferedReader(fw);*/

                
                /*while (ret!=null)
                {
                    ret = bw.readLine();
                    System.out.println(ret);
                }*/
                //System.out.println(scan.nextLine());
                do
                {
                    /*boolean notNull = true;
                    notNull = scan.hasNextLine();*/

                    //System.out.println(scan.nextLine());
                    
                    
                    array[count] = Integer.parseInt(scan.nextLine());
                    count++;
                    //scan.nextLine();
                    //ret = bw.readLine();
                    //array[count] = Integer.parseInt(ret);
                    
                    //System.out.println(ret);
                    //retCount++;
                    //array[count] = Integer.parseInt(ret);
                } while (scan.hasNextLine()!=false);
                
                JOptionPane.showMessageDialog(null, "Todos los números del archivo han sido agregados exitosamente al arreglo.\nFavor de seleccionar la opción 'Show Contents' del menú con tal de ver reflejada la acción.", "Importe Exitoso", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Count: " + count);
                /*for (int i=0; i<count; i++)
                {
                    System.out.println(array[i]);
                }*/
                
                //System.out.println("RetCount: " + retCount);
                
                /*System.out.println(bw.readLine());
                
                for (int i=0; i<retCount; i++)
                {
                    array[count] = Integer.parseInt(bw.readLine());
                }*/
                    
                /*ret = bw.readLine();
                System.out.println(bw.readLine());
                */
                
//                bw.close();
                //fw.close();


                
                
                /*FileInputStream inStream = new FileInputStream(file);
                DataInputStream dataStream = new DataInputStream(inStream);
                
                array[count] = System.out.println("Recovered int: " + dataStream.readInt());*/
                
                
                
                //int fileSize = (int)file.length();
                
                //System.out.print(fileSize);
                
            } catch(IOException | NumberFormatException | ArrayIndexOutOfBoundsException e)
            {
                if (count == array.length)
                {
                    JOptionPane.showMessageDialog(null, "Lo sentimos, el arreglo no pudo almacenar todos los datos del archivo.\nSólo se guardaron los primeros que encontraron lugar.", "Exceso de datos en archivo", JOptionPane.WARNING_MESSAGE);
                    System.out.println("Error: " + e);
                } 
                /*else if (e.getMessage().equals("null"))
                    System.exit(0);*/
                else
                {
                    JOptionPane.showMessageDialog(null, "No ha sido posible añadir datos del archivo.", "Error al leer el archivo.", JOptionPane.ERROR_MESSAGE);
                    System.out.println("Error: " + e);
                }     
            }
            
            //Array.array[count] = recoveredInt;
            //if (file.isFile()/*file.exists()*/)
            /*{
                System.out.println("Yessiree");
            }*/
        }
        
        /* Works like a charm
         * I was afraid that <str> and <i> would return to their default, initialized values if the Method was summoned more than once
           Thankfully, they don't.
         * Oh wait. Of course they wouldn't.
         */
        public void deleteOne()
        {
            int num, pos;
            boolean found = false;
            
            try
            {
                num = Integer.parseInt(JOptionPane.showInputDialog(null, "Favor de ingresar el número entero a eliminar del arreglo: ", "Borrar elemnto", JOptionPane.INFORMATION_MESSAGE));
                
                for (int i=0; i<count; i++)
                {
                    if (array[i]==num)
                    {
                        found = true;
                        pos = i;
                        
                        for (int j=pos; j<count; j++)    
                            array[j] = array[j+1];
                        
                        count--;
                    }
                }
                
                if (found==true)
                    JOptionPane.showMessageDialog(null, "Número(s) eliminado exitosamente del arreglo.\nFavor de seleccionar la opción 'Show Contents' del menú con tal de ver reflejada la acción.", "Operación Exitosa", JOptionPane.INFORMATION_MESSAGE);
                else
                    JOptionPane.showMessageDialog(null, "Element not found.", "Búsqueda fallida", JOptionPane.WARNING_MESSAGE);

            } catch (Exception e)
            {
                if (e.getMessage().equals("null"))
                    System.out.println("Ha decidido no eliminar.");
                /*if (found==false)
                    JOptionPane.showMessageDialog(null, "No se ha podido encontrar el número ingresado en el arreglo.\nFavor de intentar la función nuevamente.", "Búsqueda fallida", JOptionPane.WARNING_MESSAGE);
                else
                {*/
                else
                {
                    JOptionPane.showMessageDialog(null, "El dato que ha solicitado ingresar no es de tipo entero.\nLe pedimos de favor ingresar un dato aceptable.", "Tipo de Dato erróneo", JOptionPane.ERROR_MESSAGE);
                    System.out.println("Error de tipo:" + e);
                }
                    
                //}
            }

        }
        
        public String showContents()
        {
            String str = "";
            //String str = JOptionPane.showInputDialog(null, "Just write something", "TextArea appended", JOptionPane.INFORMATION_MESSAGE);
            for (int i=0; i<count; i++)
            {
                str = str + (i+1) + ". " + array[i] + "\n";
                //thing.txtArea.append("" + count +". " + array[i] + "\n");
            }
            
            System.out.println("Count: " + count);
           //thing.txtArea.append((count+1)+". " + str + "\n");
           return str;
        }
        
        
}
