/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 10 Sample Program: Compute the annual average rain fall
                                and the variation from monthly average.
                                Use month name as a prompt for
                                inputting monthly average values.

    File: Ch10Rainfall2.java
*/

import java.text.*;
import javax.swing.*;

/*
 *  A sample program from Section 10.1 to compute the
 *  annual rainfall and variations for monthly average.
 *
 *  In this version, the string values are used for month names.
 *
 * @author Dr. Caffeine
 *
 */
class Ch10Rainfall2 {

    public static void main (String[] args) {

        String[] monthName = { "January", "February", "March",
                               "April", "May", "June", "July",
                               "August", "September", "October",
                               "November", "December"  };

        DecimalFormat df = new DecimalFormat("0.00");

        double[]  rainfall = new double[12];

        double    annualAverage,
                  sum,
                  difference;

        sum = 0.0;

        for (int i = 0; i < 12; i++) {

            rainfall[i] = Double.parseDouble(
                                JOptionPane.showInputDialog(null,
                                        "Rainfall for" + monthName[i]));
            sum += rainfall[i];
        }

        annualAverage = sum / 12.0;

        System.out.println( "Annual Average Rainfall: " +
                             df.format(annualAverage ) );

        System.out.println("\n\n");


        for (int i = 0; i < 12; i++) {
            System.out.print(i+1); //month #

            //average rainfall for the month
            System.out.print("          " + df.format(rainfall[i]));

            //difference between the monthly and annual averages
            difference = Math.abs( rainfall[i] - annualAverage );
            System.out.println("           " + df.format(difference));
        }
    }
}