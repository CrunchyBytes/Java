/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 10 Sample Program: Illustrate the manipulation of
                               a List

    File: Ch10FriendsList.java
*/

import java.util.*;

class Ch10FriendsList {

    public static void main(String[] arg) {
        Person   person;
        List     friends;
        Iterator iterator;

        //Add members to a list
        friends = new ArrayList( );

        person = new Person("jane", 10, 'F');
        friends.add( person );

        person = new Person("jack",  6, 'M');
        friends.add( person );

        person = new Person("jill",  8, 'F');
        friends.add( person );

        person = new Person("john", 14, 'M');
        friends.add( person );

        //Scan through the list
        iterator = friends.iterator( );

        while ( iterator.hasNext( ) ) {

            person = (Person) iterator.next( );

            System.out.println( person.getName( ) );
        }

        //Remove the second person
        //and scan again
        friends.remove(1);

        System.out.println("\n");
        iterator = friends.iterator( );
        while ( iterator.hasNext( ) ) {
            person = (Person) iterator.next( );

            System.out.println( person.getName( ) );
        }

    }
}