/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 10 Sample Program: Compute different statistics
                                from monthly rainfall averages.

    File: Ch10RainfallStat.java
*/

import java.text.*;
import javax.swing.*;


/*
 * More examples of using an array of primitive data.
 *
 * @author Dr. Caffeine
 *
 */
class Ch10RainfallStat {

    public static void main (String[] args) {

        DecimalFormat df = new DecimalFormat("0.00");

        String[] monthName = { "January", "February", "March",
                               "April", "May", "June", "July",
                               "August", "September", "October",
                               "November", "December"  };

        double[]  rainfall = new double[12];

        double[]  quarterAverage = new double[4];

        double    annualAverage,
                  sum,
                  difference;

        double    oddMonthSum, oddMonthAverage,
                  evenMonthSum, evenMonthAverage;


        sum = 0.0;

        for (int i = 0; i < rainfall.length; i++) {

            rainfall[i] = Double.parseDouble(
                                JOptionPane.showInputDialog(null,
                                        "Rainfall for" + monthName[i]));
            sum += rainfall[i];
        }

        annualAverage = sum / 12.0;

        System.out.println( "Annual Average Rainfall: " +
                             df.format(annualAverage ) );

        System.out.println("\n\n");


        oddMonthSum  = 0.0;
        evenMonthSum = 0.0;

        ///////////// Odd and Even Month Averages //////////////////

        //----------------- Variation ---------------------/
        /*
        for (int i = 0; i < rainfall.length; i += 2 ) {
            oddMonthSum += rainfall[i];
            evenMonthSum += rainfall[i+1];
        }
        */
        //-------------------------------------------------/

        //compute the average for the odd months
        for (int i = 0; i < rainfall.length; i += 2) {

            oddMonthSum += rainfall[i];
        }

        oddMonthAverage = oddMonthSum / 6.0;

        //compute the average for the even months
        for (int i = 1; i < rainfall.length; i += 2) {

            evenMonthSum += rainfall[i];
        }

        evenMonthAverage = evenMonthSum / 6.0;

        System.out.println( "Odd Month Rainfall Average: " +
                             df.format(oddMonthAverage ) );

        System.out.println("\n");

        System.out.println( "Even Month Rainfall Average: " +
                             df.format(evenMonthAverage ) );

        System.out.println("\n");


        /////////////////// Quarter Averages //////////////////////

        for (int i = 0; i < 4; i++) {

            sum = 0;

            for (int j = 0; j < 3; j++) {    //compute the sum of
                sum += rainfall[3*i + j];    //one quarter
            }

            quarterAverage[i] = sum / 3.0;   //average for Quarter i+1

            System.out.println( "Rainfall Average Qtr " + (i+1) + ": " +
                                df.format(quarterAverage[i]) );

        }
   }
}