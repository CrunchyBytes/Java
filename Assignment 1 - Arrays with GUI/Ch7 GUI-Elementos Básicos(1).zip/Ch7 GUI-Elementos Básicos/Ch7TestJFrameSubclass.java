/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 7 Sample Program: Displays a default Ch7JFrameSubclass window

    File: Ch7TestJFrameSubclass.java

*/

class Ch7TestJFrameSubclass {

    public static void main( String[] args ) {

        Ch7JFrameSubclass1 myFrame;

        myFrame = new Ch7JFrameSubclass1();

        myFrame.setVisible(true);
    }
}