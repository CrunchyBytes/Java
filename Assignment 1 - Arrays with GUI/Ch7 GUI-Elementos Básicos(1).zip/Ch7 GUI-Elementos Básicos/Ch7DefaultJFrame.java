/*
    Introduction to OOP with Java 3rd Ed, McGraw-Hill

    Wu/Otani

    Chapter 7 Sample Program: Displays a default JFrame window

    File: Ch7DefaultJFrame.java

*/

import javax.swing.*;

class Ch7DefaultJFrame {

    public static void main( String[] args ) {

        JFrame defaultJFrame;

        defaultJFrame = new JFrame();

        defaultJFrame.setVisible(true);
    }
}
